package shoppingCart;
/*Christopher Shane Lynn
 * Chapter 11-12
 * Final Programming Challenge, Shopping Cart
 * This set of classes creates an interactive shopping cart for an online bookstore.
 */

//Load the imports needed for processing
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.SelectionModel;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;


public class ShoppingCart extends Application
{

	
    //--------------------ADDITIONAL CLASSES-------------------------------------------------------------------	

	//Load the class that processes the info from the BookPrices.txt file in LoadInventory.java
    LoadInventory currentItems = new LoadInventory();
	
     
    //--------------------VARIABLES-------------------------------------------------------------------  

    // Setup and initialize variables to hold working data, current prices, portion of the shopping cart
    
    //Button working variables and ArrayLists
    double addCartUpdate = 0.0;
    double addCartTaxUpdate = 0.0;
    String addTitleSelection = "";
    int addInventoryIndexId = 0;
    int addPriceIndexID = 0;
    double addInventoryPrice = 0.0;
    double addTaxRate = 0.0;
    int removeIDsList = 0;
    
    ArrayList<String> selectionsItems = new ArrayList<String>();
    ArrayList<Double> selectionsItemsPrice = new ArrayList<Double>();
    ArrayList<Integer> selectionsIndex = new ArrayList<Integer>();
    ArrayList<Integer> selectionsItemsIDs = new ArrayList<Integer>();
    ArrayList<Integer> remSelectionsItemsIds = new ArrayList<Integer>();
    
    
    //Current total global variables and ArrayLists
    final double TAX_RATE = 0.07;
    double currentSubTotal = 0.0;
    double currentTax = 0.0;
    double currentOrderTotal = 0.0;
    ArrayList<String> finalSelectionsItems = new ArrayList<String>();
    ArrayList<Double> finalSelectionsItemsPrice = new ArrayList<Double>();
     
 
  //--------------------MAIN METHOD CLASS-------------------------------------------------------------------   

   //Main method, starts the program and loads the application found the start.	
   public static void main(String[] args)
   {
      launch(args);
   }
   
  //--------------------MAIN STAGE CLASS------------------------------------------------------------------- 

   //Method entry point of the application to create the scene
   @Override
   public void start(Stage primaryStage)
   {
      // Setup a try loop to call the method from the LoadInventory object to build the ArrayLists from the import file
		try
		{
			currentItems.readBookFile();
			
		} catch (IOException e1) 
		{
			   	  e1.printStackTrace();
	              System.out.println("file open error"); 
		}    
	    
				
	//--------------------LISTS-------------------------------------------------------------------
		
		//Load up the ArrayLists from LoadInventory class and populate them with the values
		ArrayList<String> inventoryTitles = new ArrayList<String> (currentItems.getInventoryTitles());
		ArrayList<Double> inventoryPrices = new ArrayList<Double> (currentItems.getInventoryTitlePrices());
		
		//Convert the ArrayLists to ObservableLists to be used for the ListViews
		ObservableList<String> observListTitles = FXCollections.observableArrayList(inventoryTitles);
		ObservableList<Double> observListPrices = FXCollections.observableArrayList(inventoryPrices);
		
		//Build the ListView that holds and displays the book title information from the observable list 
	    ListView<String> bookView = new ListView<>();
	    bookView.setPrefSize(350, 500);
	    bookView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
	    bookView.getItems().addAll(observListTitles);
	    
	    //Build the ListView that holds and displays the book price information for testing  
	    ListView<Double> priceView = new ListView<>();
	    priceView.setPrefSize(350, 500);
	    priceView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
	    priceView.getItems().addAll(observListPrices);
	    
	    //Build the ListView that starts empty and holds items added from the bookView list (the shopping cart).
	    ListView<String> cartView = new ListView<>();
	    cartView.setPrefSize(350, 500);
	    cartView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
	    

	//--------------------LABELS-------------------------------------------------------------------	    
	   
	  //List titles for the ListView panels holding the book titles
	    Label bookLabel = new Label("Pick a Book");
	    Label cartLabel = new Label("Shopping Cart");
	    
	  //Create the container and output labels for the cart subtotal in the status window
	    Label subtotalDescriptor = new Label("Subtotal:");
	    Label subtotalOutputLabel = new Label("0.00");
	    HBox subtotalHBox = new HBox(10,subtotalDescriptor, subtotalOutputLabel);
	    
	  //Create the container and output labels for the cart tax in the status window
	    Label taxDescriptor = new Label("Tax:");
	    Label taxOutputLabel = new Label("0.00");
	    HBox taxHBox = new HBox(10,taxDescriptor, taxOutputLabel);
	    
	  //Create the container and output labels for the cart order total in the status window
	    Label totalDescriptor = new Label("Order Total:");
	    Label totalOutputLabel = new Label("0.00");
	    HBox totalHBox = new HBox(10,totalDescriptor, totalOutputLabel);
      
	    
	    
 //--------------------BUTTONS AND ACTIONS-------------------------------------------------------------------  
	    
	    
	//-----------ADD BUTTON -------// Setup the Add To Cart Button and actions on click
	    Button addToCartButton = new Button("Add To Cart");
	    addToCartButton.setOnAction(e ->
	    {
	    	//Clear the temporary lists before working new items
	    	selectionsItems.clear();
	    	selectionsIndex.clear();
	    	selectionsItemsPrice.clear();
	    	
	    	//Create an ObservableList of the selected items from the ListView.
	        ObservableList<String> selections = bookView.getSelectionModel().getSelectedItems();
	        ObservableList<Integer> selectionsID = bookView.getSelectionModel().getSelectedIndices();
	        
	        //Add current selections to into the temporary book title ArrayList
	        selectionsItems.addAll(selections);
	        selectionsIndex.addAll(selectionsID);
	        selectionsItemsIDs.addAll(selectionsIndex);
	        
	        //Setup a loop to get the individual variables from the selection arrays for titles and prices.
	        for (int index = 0; index < selections.size(); index++)
	        {
	    	  
	    	  //Gets the individual title value from the temporary selection array 
	    	  addPriceIndexID = selectionsIndex.get(index);
	    	  
	    	  //Use the retrieved element index ID for the book title to retrieve the corresponding price value
	    	  addInventoryPrice = inventoryPrices.get(addPriceIndexID);
	    	  
    		  //Add the individual book value to the temporary price array
    		  selectionsItemsPrice.add(addInventoryPrice);
	        }   
	    	   
	        //Update the cartListView (the shopping cart with current selections
	    	cartView.getItems().addAll(selections);
	          
	        //Setup a for loop to update the price totals for the current selections 
	    	for(int index = 0; index < selectionsItemsPrice.size(); index++)
	    	{
	    	  double addCartPrice = selectionsItemsPrice.get(index);
	    	  addCartUpdate += addCartPrice;
	    	}
	    	  
	    	//Calculate the tax rate for the current selections
	        addTaxRate = (TAX_RATE * addCartUpdate);
	        addCartTaxUpdate = addTaxRate;
	        
	        //Update globals with current price
	        currentSubTotal = addCartUpdate;
	  		currentTax = addCartTaxUpdate;
	  		currentOrderTotal = (currentSubTotal + currentTax);
	  		
	  		//Update choices to the final choices ArrayLists
	  		finalSelectionsItems.addAll(selectionsItems);
	  		finalSelectionsItemsPrice.addAll(selectionsItemsPrice);
	  		  
	        //Update the status label text with the updated totals
	        subtotalOutputLabel.setText(String.format("%,.2f", currentSubTotal));
	        taxOutputLabel.setText(String.format("%,.2f", currentTax));
	        totalOutputLabel.setText(String.format("%,.2f", currentOrderTotal));
	    });
	    
	    
	//-----------REMOVE FROM CART BUTTON -------// Setup the Remove from Cart Button and actions on click	    
	   
	    
	    Button removeFromCartButton = new Button("Remove From Cart");
	    removeFromCartButton.setOnAction(e ->
	    {
	      //Setup a message for an empty cart
	     
	      if(currentOrderTotal < 0.1)
	      { 
	    	//Display a window to the user if the cart is empty.
			JOptionPane.showMessageDialog(null, "There is nothing in the cart to remove!", "Remove from Cart", JOptionPane.ERROR_MESSAGE);
	      }
	      {  
	    	//Clear the temporary lists before working new items
	    	selectionsItems.clear();
	    	selectionsIndex.clear();
	    	selectionsItemsPrice.clear();
	    	remSelectionsItemsIds.clear();
	    	
	    	//Create an ObservableList of the selected items from the ListView.
			ObservableList<String> cartSelections = cartView.getSelectionModel().getSelectedItems();
			ObservableList<Integer> cartSelectionsID = cartView.getSelectionModel().getSelectedIndices();
		   				
	        //Add current selections to into the temporary book title ArrayList
	        selectionsItems.addAll(cartSelections);
	        selectionsIndex.addAll(cartSelectionsID);

	        //Setup a loop to get the individual variables from the selection arrays for titles and prices.
	        for (int index = 0; index < cartSelections.size(); index++)
	        //for (int index = 0; index < selectionsItems.size(); index++)
	        {
	    	  //Gets the individual title value from the temporary selection array 
	    	  addTitleSelection = selectionsItems.get(index);
	    	  addPriceIndexID = selectionsIndex.get(index);
	    	  
	    	  //Compares the selection to the book master list to get the element index ID
	    	  addInventoryIndexId = selectionsItemsIDs.get(addPriceIndexID);
	    	  
	    	  //Use the retrieved element index ID for the book title to retrieve the corresponding price value
    		  addInventoryPrice = inventoryPrices.get(addInventoryIndexId);
    		  
    		  //Add the price and element IDs to the temp arrays.  Update the cart view.
    		  selectionsItemsPrice.add(addInventoryPrice);
    		  remSelectionsItemsIds.add(addInventoryIndexId);
    		  cartView.getItems().remove(addPriceIndexID);
	    	}   

	       //Setup a loop to remove the IDs from the temp array for updating correct cost
	       for (int index = 0; index < remSelectionsItemsIds.size(); index++)
	       //for (int index = 0; index < selectionsItems.size(); index++)
	       {
	    	  //Create a variable to hold the element ID from the selections array
	    	  removeIDsList = remSelectionsItemsIds.get(index);
	    	  
	    	  //Create a variable to hold the master element ID from the lookup
	    	  int removeIDValue = selectionsItemsIDs.indexOf(removeIDsList);
	    	  
	    	  //Remove the corresponding element from the selections list.
	    	  selectionsItemsIDs.remove(removeIDValue);
	       }
	       
	       //Setup a for loop to update the price totals for the current selections 
	       for(int index = 0; index < selectionsItemsPrice.size(); index++)
	       //for(int index = 0; index < selectionsItems.size(); index++)
	       {
	    	  double addCartPrice = selectionsItemsPrice.get(index);
	    	  addCartUpdate -= addCartPrice;
	       }

	       //Extra Update for the cartListView (the shopping cart) to remove current selections
	       cartView.getItems().removeAll(cartSelectionsID);
	       
	       //Calculate the tax rate for the current selections
	       addTaxRate = (TAX_RATE * addCartUpdate);
	       addCartTaxUpdate = addTaxRate;
	        
	       //Update globals with current price
	       currentSubTotal = addCartUpdate;
	       currentTax = addCartTaxUpdate;
	       currentOrderTotal = (currentSubTotal + currentTax);
	  		
	       //Update choices to the final choices ArrayLists
	       finalSelectionsItems.removeAll(selectionsItems);
	       finalSelectionsItemsPrice.removeAll(selectionsItemsPrice);
	  		  
	       //Update the status label text with the updated totals
	       subtotalOutputLabel.setText(String.format("%,.2f", currentSubTotal));
	       taxOutputLabel.setText(String.format("%,.2f", currentTax));
	       totalOutputLabel.setText(String.format("%,.2f", currentOrderTotal));
		 }

	    });

	    
	    
	  //-----------CLEAR CART BUTTON -------// Setup the Clear Cart Button and actions on click	    
	   
	    Button clearCartButton = new Button("Clear Cart");
	    clearCartButton.setOnAction(e ->
	    {
	    	//Remove all of the active selections from the cart ListViews and ArrayLists.
	    	cartView.getItems().clear();
	  		selectionsItems.clear();
	  		selectionsIndex.clear();
	  		selectionsItemsPrice.clear();
	  		selectionsItemsIDs.clear();
	  		finalSelectionsItems.clear();
	  		finalSelectionsItemsPrice.clear();
	       
	        //Update globals to clear the price fields
	        addCartUpdate = 0;
	        currentSubTotal = 0;
	  		currentTax = 0;
	  		currentOrderTotal = (currentSubTotal + currentTax);
	  		
	        //Update the status label text with the cleared totals
	        subtotalOutputLabel.setText(String.format("%,.2f", currentSubTotal));
	        taxOutputLabel.setText(String.format("%,.2f", currentTax));
	        totalOutputLabel.setText(String.format("%,.2f", currentOrderTotal));
	    });
	    
	    
	  //-----------CHECKOUT BUTTON -------//	Setup the Checkout Button and actions on click
	    Button checkoutButton = new Button("Checkout");
 		checkoutButton.setOnAction(e ->
	    {
	       //Create the format to use dates and times
	       String timeStamp = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
	       String fntimeStamp = new SimpleDateFormat("MM-dd-yyyy.HH.mm.ss").format(Calendar.getInstance().getTime());

	       //Create variables to use for the receipt format
	       String filename = "Receipt-"+fntimeStamp+".txt"; 
	       String receiptBookTitle = "Book Title";
	       String receiptPriceTitle = "Price";
	       String titleSeparator = "-------------------------";
	       String priceSeparator = "---------";

	       //Setup the try/catch to account for any file errors
	       try {
	      	   //Create and open the receipt file
	    	   PrintWriter receiptFile = new PrintWriter("src/shoppingCart/"+filename);
				   
				//Write the receipt to the file
	    	   receiptFile.printf("Receipt: " + timeStamp +"\n");
	    	   receiptFile.printf(" \n");
	    	   receiptFile.printf("%-28s%-8s\n", receiptBookTitle, receiptPriceTitle);
	    	   receiptFile.printf("%-28s%-8s\n", titleSeparator, priceSeparator);

	    	   //Create the loop to write each selection and price to the receipt
	    	   for (int index = 0; index < finalSelectionsItems.size(); index++)
	    	   {
	    		 receiptFile.printf("%-28s", finalSelectionsItems.get(index));
	    		 receiptFile.printf("$%8.2f\n", finalSelectionsItemsPrice.get(index)); 
	    	   }

	    	   //Write the totals part of the receipt
	    	   receiptFile.printf(" \n");
	    	   receiptFile.printf("%-28s$%,8.2f\n", "Sub Total", currentSubTotal);
	    	   receiptFile.printf("%-28s$%,8.2f\n", "Tax", currentTax);
	    	   receiptFile.printf("%-28s%-8s\n", titleSeparator, priceSeparator);
	    	   receiptFile.printf("%-28s$%,8.2f\n", "Grand Total", currentOrderTotal);
				   
	           //Close the and finish writing the receipt file
		       receiptFile.close();
		           
	       } catch (FileNotFoundException e1) {
			   	  e1.printStackTrace();
	            System.out.println("file open error"); 
	       }

	       //Call the clearCartButton to activate and clear the cart.
	       clearCartButton.fire();
	       
	       //Display a confirmation window to the user for successful file creation.
	       JOptionPane.showMessageDialog(null, "Thank you for shopping with Columbia College Books! \n Your receipt has been printed.");
	    });

	    
  //--------------------GUI COMPONENTS ------------------------------------------------------------------- 
   
	  //Build the VBox to hold the Book Listview
	    VBox vboxBookListView = new VBox(5, bookView);
	    vboxBookListView.setPadding(new Insets(5));
	    vboxBookListView.setAlignment(Pos.BASELINE_LEFT);
	 
	  //Build the VBox to hold the Book Listview
		VBox vboxCartListView = new VBox(5, cartView);
		vboxCartListView.setPadding(new Insets(5));
		vboxCartListView.setAlignment(Pos.BASELINE_CENTER);
	    	    
      //Build the VBox to hold the Add button
	    HBox vboxAddButton = new HBox(5, addToCartButton);
	    vboxAddButton.setPadding(new Insets(5));
	    vboxAddButton.setAlignment(Pos.CENTER);
	    
      //Build the VBox to hold the cart buttons
	    VBox vboxCartButtons = new VBox(5, removeFromCartButton, clearCartButton, checkoutButton);
	    vboxCartButtons.setPadding(new Insets(5));
	    vboxCartButtons.setAlignment(Pos.CENTER);
	  
	  //Build the HBox to hold the output labels
	    HBox statusTotals = new HBox(10, subtotalHBox, taxHBox, totalHBox);
	    //statusTotals.setPadding(new Insets(5));		//Enable if more spacing is desired
	    statusTotals.setAlignment(Pos.BASELINE_LEFT);
	    
	  //Create a GridPane for scene presentation layout elements
	    GridPane mainWindowPane = new GridPane();
	    
	  //Add the GUI components to the GridPane.		 	// Grid Layout for GUI parts
	    mainWindowPane.add(bookLabel, 0, 0);  			// Col 0 | Col 1 | Col 2 | Col 3
	    mainWindowPane.add(bookView, 0, 1);  			// Row 0 | Row 0 | Row 0 | Row 0
	    mainWindowPane.add(vboxAddButton, 1, 1);		// Row 1 | Row 1 | Row 1 | Row 1
	    mainWindowPane.add(cartLabel, 2, 0);			// Row 3 | Row 3 | Row 3 | Row 3
	    mainWindowPane.add(cartView, 2, 1); 			// 
	    mainWindowPane.add(vboxCartButtons, 3, 1);		// Input format: Col #, Row #)
	    mainWindowPane.add(statusTotals, 0, 2); 
	    //mainWindowPane.add(priceView, 4, 1);			//Enable for testing

	  //Set the gap sizes for each component.
	    mainWindowPane.setVgap(10);
	    mainWindowPane.setHgap(10);
	     
	  //Set the GridPane's padding.
	    mainWindowPane.setPadding(new Insets(30));
	    
	  //Add the main GUI view to the scene.
	    Scene mainScene = new Scene(mainWindowPane);
	    
	  //Add the primary scene to the Stage.
	    primaryStage.setScene(mainScene);
	    
	  //Set the title for the stage (main program window).
	    primaryStage.setTitle("Columbia College Books");
	    
	  //Display the window.
	    primaryStage.show();
	  
	//Close the start class section
   }
   //--------------------MAIN STAGE CLASS END-------------------------------------------------------------------
   
//Close the primary class ShoppingCart 
}
