package shoppingCart;
/*Christopher Shane Lynn
 * Chapter 11-12
 * Final Programming Challenge, Shopping Cart
 * This set of classes creates an interactive shopping cart for an online bookstore.
 */

//Setup the imports to process the input file
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class LoadInventory {

	//Setup the lists to hold the data from the import file
	ArrayList<String> inventoryTitleList = new ArrayList<String>();
    ArrayList<Double> inventoryPriceList = new ArrayList<Double>();
    ArrayList<String> inventoryMasterList = new ArrayList<String>();
    
    //Setup the method that opens and records the data from the import file
    public void readBookFile() throws IOException
	{

    	//Open the input file.
	    File file = new File("src/shoppingCart/BookPrices.txt");
	    Scanner inFile = new Scanner(file);

	    // Setup a loop to read the input file contents.
	    while (inFile.hasNext())
	    {
	    	//Read a line from the input file
	    	String itemTitlePrice = inFile.nextLine();
	        
	    	//Add it to the MasterList ArrayList
	    	inventoryMasterList.add(itemTitlePrice);
	    	
	    	//Pull apart the input files values separated by a ,
	    	String[] tokens = itemTitlePrice.split("[,]");
	    	  
	    	//Store 1st value of book title to string value
	    	String bookTitle = tokens[0];
	    	  
	    	//Convert 2nd value of price to double value
	    	double bookPrice = Double.parseDouble(tokens[1]);
	    	  
	        //Add the contents from the import file to the corresponding ArrayLists.
	    	inventoryTitleList.add(bookTitle);
	    	inventoryPriceList.add(bookPrice);
	      }
	      
	      //Close the input file.
	      inFile.close();
	   }
	
	//Setup the method to retrieve the loaded book titles
	public ArrayList<String> getInventoryTitles()
	{
		return inventoryTitleList;
	}

	//Setup the method to retrieve the loaded book title prices
	public ArrayList<Double> getInventoryTitlePrices()
	{
		return inventoryPriceList;
	}
	
	//Setup the method to retrieve the loaded book title prices
	public ArrayList<String> getInventoryMasterList()
	{
		return inventoryMasterList;
	}
}
