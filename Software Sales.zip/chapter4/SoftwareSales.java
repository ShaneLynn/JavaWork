package chapter4;
/*Christopher S Lynn
 * Chapter 4
 * Programming Challenge 4 pg. 267
 * This class sets up SoftwareSales to be used by SoftwareSalesDemo.java calls.
 * 
 */

public class SoftwareSales {

	//Setup the fields needed
	private int	UnitsSold;				//Stores a private instance for UnitsSold fields
	private double UnitPrice = 99.0;	//Sets the cost per item in a private instance for UnitPrice fields
	private double Discount;			//Stores a private instance for Discount fields
	private double DiscountRate;		//Stores a private instance for the Discount rate field
	private double Cost;				//Stores a private instance for Cost fields
	
	
	
	//Setup the constructor to accept the input units
	public SoftwareSales (int units) {
		UnitsSold = units;
	}

		
	/*----------------
	 * This section is for accessor methods (or the getters).
	 *-------------------*/
	
	//This method reads arguments passed to UnitsSold variable and stores them.  Only returns information.
	public int getUnitsSold()
	{
		return UnitsSold;
	}

	//This method reads the argument request from SoftwareSalesDemo, and calculates the discount percent.
	public double getDiscount()
	{

		if (UnitsSold < 10) 
			DiscountRate = 0.0;
		if (UnitsSold >= 10) 
			DiscountRate = 0.20;
		if (UnitsSold >= 20) 
			DiscountRate = 0.30;
		if (UnitsSold >= 50) 
			DiscountRate = 0.40;
		if (UnitsSold >= 100) 
			DiscountRate = 0.50;
		
		 
		Discount = (UnitsSold * UnitPrice) * DiscountRate;
		
		return Discount;
	}

	//This method reads the argument request from SoftwareSalesDemo, and calculates the final sale cost.
	public double getCost()
	{

		Cost = (UnitsSold * UnitPrice) - Discount;
				
		
		return Cost;
	}


}