package chapter7;
/*Christopher S Lynn
 * Chapter 7
 * Programming Challenge 2 pg. 536
 * This program collects user input for employee hours and pay rates and displays
 * the total gross pay for all employees.
 */

//Setup utilities used by the program to collect input and format display output
import java.text.DecimalFormat;
import java.util.Scanner;

//Setup the main class program
public class PayrollDemo {
	public static void main(String[] args) {

		//Create an object from the payroll class to access the arrays
		Payroll data = new Payroll();

		//Initialize the variables needed to transfer data
		int hoursWorked = 0;						// Placeholder for Hours worked
		int totalEmployees = data.NUM_EMPLOYEES;	// Sets the counter equal to the class maximum in Payroll.java
		double payRate = 0.0;						// Placeholder for Hourly pay rate

	
		// Create a Scanner object for user input from the keyboard.
		Scanner keyboard = new Scanner(System.in);

		//Setup a user input loop to collect and validate employee hours worked and pay rate
		for (int index = 0; index < totalEmployees ; index++)
			{
				//User input to collect the employee hours worked and store it in the variable
				System.out.print("Enter the hours worked by employee number " + (data.getEmployeeID(index)) + ": ");
				hoursWorked = keyboard.nextInt();
				
			   	//Error checking validation for hours worked, can't be less than 0
				while (hoursWorked < 0) 
				{	
				System.out.print("ERROR: Enter 0 or greater for hours: ");	  
				hoursWorked = keyboard.nextInt();
				}
				
				//Transfer the variable hours data into the array storage
				data.setHours(index, hoursWorked);

				//User input to collect the employee's pay rate and store it in the variable
				System.out.print("Enter the hourly pay rate for employee number " + (data.getEmployeeID(index)) + ": ");
				payRate = keyboard.nextDouble();
					
				//Error checking validation for pay rate, can't be less than $6.00 p/h
				while (payRate < 6.00 ) 
				{
				System.out.print("ERROR: Enter 6.00 or greater for pay rate: ");	  
				payRate = keyboard.nextDouble();
				}
				
				//Transfer the variable payRate data into the array storage
				data.setPayRate(index, payRate);
			}	

		//Clear the any newline buffer from data entry
		keyboard.nextLine();
		
		//Setup the format to print in currency form
		DecimalFormat dollar = new DecimalFormat("#,##0.00");
		
		//Display the header for the payroll data
		System.out.println("\nPAYROLL DATA");
		System.out.println("============");

		//Display the final results using a loop to collect the data from each array
		for (int index = 0; index < totalEmployees; index++)
		{
			System.out.println("Employee ID: " + data.getEmployeeID(index));
			//System.out.println("Hours Worked: " + data.getHours(index));	//Use to check that data is being passed into field
			//System.out.println("PayRate: " + data.getPayRate(index));		//Use to check that data is being passed into field
			System.out.println("Gross pay: $" + dollar.format(data.getGrossPay(index))+ "\n");
		}
		
			
	//Close the scanner input to avoid memory leaks
	keyboard.close();
	}
	
//End the program
}

