package chapter7;
/*Christopher S Lynn
 * Chapter 7
 * Programming Challenge 2 pg. 536
 * This program collects hotel floor and room counts to display occupancy metrics
 * 
 */

//Creates a new class with arrays to track paryoll data
public class Payroll {

	//Sets up the field to hold the total employees in records.  Uses final to prevent modification.
	public final int NUM_EMPLOYEES = 7;

	//Creates the array that holds employee ID numbers
	private int[] employeeId = { 5658845, 4520125, 7895122, 8777541, 8451277, 1302850, 7580489 };
	
	//Creates the array that holds the total hours worked for each employee
	private int[] hours = new int[NUM_EMPLOYEES];

	//Creates the array that holds the current pay rate for each employee
	private double[] payRate = new double[NUM_EMPLOYEES];

	//Creates the array that holds the gross pay information for each employee
	private double[] wages = new double[NUM_EMPLOYEES];



	
	//============== This section sets up the mutators (setters) for the arrays =================== >>>
	
	//This method collects a new employee ID for each employee, should it be needed, and transfers it into the array index
	public void setEmployeeID(int index, int ID)
	{
		employeeId[index] = ID;
	}


	//This method collects the total hours worked for each employee and transfers it into the corresponding array index 
	public void setHours(int index, int vhours)
	{
		hours[index] = vhours;
	}


	
	//This method collects the current pay rate for each employee and transfers it into the corresponding array index
	public void setPayRate(int index, double vpayRate)
	{
		payRate[index] = vpayRate;
	}

	
	
	//This method collects the calculated total gross for each employee and transfers it into the corresponding array index
	
	public void setWages(int index, double vWages)
	{
		wages[index] = vWages;
	}

	
	//============== This section sets up the accessors (getters) for the arrays =================== >>>
	
	
	//This method reads the index number passed from the program and returns the corresponding employee ID array location.
	public int getEmployeeID(int index)
	{
		return employeeId[index];
	}

	
	//This method reads the index number passed from the program and returns the corresponding total employee hours worked array location.
	public int getHours(int index)
	{
		return hours[index];
	}

	
	
	//This method reads the index number passed from the program and returns the corresponding current employee pay rate array location.
	public double getPayRate(int index)
	{
		return payRate[index];
	}


	
	//This method reads the index number passed from the program and returns the corresponding employee ID array location.
	public double getWages(int index)
	{
		return wages[index];
	}

	
	//Sets up a method to collect an argument for the index number and calculates the gross pay for 
	//the employee ID at that index number.
	public double getGrossPay(int index)
	{
		int vhours = 0;
		double vpayR = 0.0;
		double vGPay = 0.0;
		
		vhours = getHours(index);
		vpayR = getPayRate(index);
		vGPay = (vhours * vpayR);
		
		setWages(index, vGPay);
		
		return wages[index];
	}		

//End the Class
}
